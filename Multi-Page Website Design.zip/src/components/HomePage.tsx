import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Check, 
  AlertTriangle, 
  Phone, 
  Calendar, 
  DollarSign,
  TrendingUp,
  MapPin,
  ArrowRight,
  PlayCircle,
  Flag
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function HomePage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section - Full Viewport */}
      <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0icmdiYSgyNTUsMTIwLDAsLjA1KSIvPjwvZz48L3N2Zz4=')] opacity-30" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-7xl">
                Get More Customers. Period.
              </h1>
              <p className="text-2xl text-slate-300 mb-8 leading-relaxed">
                We build websites, run SEO, and manage social media for Warren & Metro Detroit businesses. <span className="text-orange-600">Your phone rings more. You close more deals.</span> That's it.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-12 py-8 shadow-2xl shadow-orange-600/30">
                  Get Free Growth Plan
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-slate-700 text-white hover:bg-slate-800 text-xl px-12 py-8">
                  See Real Results
                </Button>
              </div>
              
              {/* Trust Bar */}
              <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Flag className="w-6 h-6 text-orange-600" />
                  <span className="text-white">Serving Warren, Detroit, Troy & All Metro Detroit</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0" />
                    <span>More Leads</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0" />
                    <span>More Bookings</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0" />
                    <span>More Sales</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Animated Dashboard */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-orange-600/20">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXNoYm9hcmQlMjBhbmFseXRpY3N8ZW58MXx8fHwxNzYxOTE2NjUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Growth dashboard"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent" />
                
                {/* Floating Notification Cards */}
                <motion.div
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 1, duration: 0.5, repeat: Infinity, repeatDelay: 3 }}
                  className="absolute top-8 left-8 bg-green-500 text-white px-4 py-2 rounded-lg shadow-xl text-sm flex items-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  New lead: Warren Auto Detail
                </motion.div>
                
                <motion.div
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 1.5, duration: 0.5, repeat: Infinity, repeatDelay: 3 }}
                  className="absolute top-24 right-8 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-xl text-sm flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  Booking confirmed
                </motion.div>
                
                <div className="absolute bottom-8 left-8 right-8 bg-slate-900/90 backdrop-blur-sm rounded-xl p-4 border border-orange-600/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-orange-600 text-sm mb-1">Monthly Revenue</div>
                      <div className="text-white text-2xl">+$23,450</div>
                    </div>
                    <TrendingUp className="w-10 h-10 text-orange-600" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl lg:text-5xl">Your Competitors Are Stealing Your Customers</h2>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-red-900/50 p-8 h-full text-center">
                <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <div className="text-6xl text-white mb-2">87%</div>
                <p className="text-slate-300 text-lg">
                  of customers find local businesses online
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-red-900/50 p-8 h-full text-center">
                <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <div className="text-3xl text-white mb-4">Your competitors rank #1 on Google</div>
                <p className="text-slate-300">
                  while you're invisible
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-red-900/50 p-8 h-full text-center">
                <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <div className="text-3xl text-white mb-4">No website = No trust</div>
                <p className="text-slate-300">
                  = No customers
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-white mb-6 text-4xl lg:text-5xl">We Fix One Thing: Get You More Customers</h2>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8"
          >
            <motion.div variants={fadeInUp}>
              <Link to="/services">
                <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 h-full hover:border-orange-600 transition-all hover:scale-105 group cursor-pointer">
                  <div className="bg-orange-600/20 w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-600/30 transition-colors">
                    <Phone className="w-10 h-10 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-4 text-2xl">More Phone Calls</h3>
                  <p className="text-slate-300 text-lg mb-6">
                    Your phone rings with qualified customers ready to buy, not tire-kickers
                  </p>
                  <div className="flex items-center text-orange-600 text-lg">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform" />
                  </div>
                </Card>
              </Link>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Link to="/services">
                <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 h-full hover:border-orange-600 transition-all hover:scale-105 group cursor-pointer">
                  <div className="bg-orange-600/20 w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-600/30 transition-colors">
                    <Calendar className="w-10 h-10 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-4 text-2xl">More Bookings</h3>
                  <p className="text-slate-300 text-lg mb-6">
                    Your schedule fills up with high-value appointments on autopilot
                  </p>
                  <div className="flex items-center text-orange-600 text-lg">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform" />
                  </div>
                </Card>
              </Link>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Link to="/services">
                <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 h-full hover:border-orange-600 transition-all hover:scale-105 group cursor-pointer">
                  <div className="bg-orange-600/20 w-20 h-20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-600/30 transition-colors">
                    <DollarSign className="w-10 h-10 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-4 text-2xl">More Revenue</h3>
                  <p className="text-slate-300 text-lg mb-6">
                    Every dollar you invest returns 3-5X in new customer revenue
                  </p>
                  <div className="flex items-center text-orange-600 text-lg">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform" />
                  </div>
                </Card>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Local Authority Section */}
      <section className="py-20 bg-slate-900/50" id="why-us">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="relative aspect-square rounded-2xl overflow-hidden border-2 border-orange-600/20">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1696943444991-def9485f89f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEZXRyb2l0JTIwY2l0eXNjYXBlfGVufDF8fHx8MTc2MjAyMzYwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Metro Detroit"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-orange-600/40 to-slate-950/80" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-20 h-20 text-white mx-auto mb-4 drop-shadow-lg" />
                    <div className="text-white text-4xl drop-shadow-lg">Metro Detroit</div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-white mb-6 text-4xl">Proudly Serving Metro Detroit Since 2023</h2>
              <p className="text-slate-300 mb-8 text-xl leading-relaxed">
                We're not some out-of-state agency. We're your neighbors in Warren, Michigan, and we're invested in local business success.
              </p>
              
              {/* Why Us - Experience & Copywriting */}
              <div className="bg-slate-900 border-2 border-orange-600/30 rounded-xl p-6 mb-8">
                <h3 className="text-white text-2xl mb-4">Why Businesses Choose Us</h3>
                <div className="space-y-4 text-slate-300">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-1" />
                    <div>
                      <strong className="text-white">We Have Real Experience:</strong> 50+ businesses served. We know what works and why — not just theory, but proven results.
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-1" />
                    <div>
                      <strong className="text-white">We Master Copywriting:</strong> Most web designers build pretty sites that don't convert. We build sites with words that sell and designs that attract clients.
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-1" />
                    <div>
                      <strong className="text-white">We've Done This For Our Own Business:</strong> Michigan Digital Foundry grew using these exact strategies. We practice what we preach.
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mb-8">
                {['Warren', 'Detroit', 'Troy', 'Sterling Heights', 'Royal Oak', 'Macomb County', 'Oakland County', 'Wayne County'].map((city) => (
                  <Badge key={city} className="bg-orange-600/20 text-orange-600 border-orange-600/30 px-4 py-2 text-base">
                    {city}
                  </Badge>
                ))}
              </div>

              <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
                Get Your Free Growth Plan
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-20 bg-slate-950" id="results">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl lg:text-5xl">Real Metro Detroit Businesses. Real Results.</h2>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full">
                <Badge className="bg-orange-600/20 text-orange-600 mb-4 text-base">Detroit Auto Detailer</Badge>
                <h3 className="text-white mb-6 text-2xl">+340% More Bookings in 90 Days</h3>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-red-900/20 border border-red-900/50 rounded-lg p-4 text-center">
                    <div className="text-red-500 text-xs mb-1">BEFORE</div>
                    <div className="text-white text-3xl">8</div>
                    <div className="text-slate-500 text-xs">bookings/month</div>
                  </div>
                  <div className="bg-green-900/20 border border-green-900/50 rounded-lg p-4 text-center">
                    <div className="text-green-500 text-xs mb-1">AFTER</div>
                    <div className="text-white text-3xl">35</div>
                    <div className="text-slate-500 text-xs">bookings/month</div>
                  </div>
                </div>
                <p className="text-slate-400">
                  "My schedule is booked solid. Best investment I've made in my business." - Mike T., Detroit
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full">
                <Badge className="bg-orange-600/20 text-orange-600 mb-4 text-base">Warren HVAC Company</Badge>
                <h3 className="text-white mb-6 text-2xl">Phone Rings 4X More</h3>
                <div className="flex items-center justify-center mb-6 py-8">
                  <Phone className="w-24 h-24 text-orange-600" />
                  <TrendingUp className="w-16 h-16 text-green-500 ml-4" />
                </div>
                <p className="text-slate-400">
                  "We went from struggling to find customers to turning jobs away. Can't keep up with demand." - John R., Warren
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full">
                <Badge className="bg-orange-600/20 text-orange-600 mb-4 text-base">Troy Plumber</Badge>
                <h3 className="text-white mb-6 text-2xl">From Page 5 to #1 on Google</h3>
                <div className="bg-slate-800 rounded-lg p-6 mb-6 text-center">
                  <div className="text-slate-500 text-sm mb-2">Google Search: "plumber troy mi"</div>
                  <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white px-4 py-3 rounded-lg mb-2">
                    #1 Your Business Name
                  </div>
                  <div className="text-xs text-green-500">Now ranking #1</div>
                </div>
                <p className="text-slate-400">
                  "I show up first when people search. Phone hasn't stopped ringing since." - Dave M., Troy
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl lg:text-5xl">Three Services. One Goal: Fill Your Pipeline.</h2>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8"
          >
            <motion.div variants={fadeInUp}>
              <Link to="/services/website">
                <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-600 transition-all group">
                  <div className="text-orange-600 text-6xl mb-4">$2,500</div>
                  <h3 className="text-white mb-4 text-2xl">Custom Websites</h3>
                  <h4 className="text-slate-300 mb-6 text-xl">A Website That Actually Brings You Customers</h4>
                  <p className="text-slate-400 mb-6">
                    Not just pretty. Built to convert visitors into paying customers 24/7. Booking systems, mobile-optimized, fast-loading, SEO-ready.
                  </p>
                  <div className="flex items-center text-orange-600 group-hover:gap-2 transition-all">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </Card>
              </Link>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Link to="/services/seo">
                <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-600 transition-all group">
                  <div className="text-orange-600 text-4xl mb-4">$1,000/month</div>
                  <h3 className="text-white mb-4 text-2xl">Local SEO</h3>
                  <h4 className="text-slate-300 mb-6 text-xl">Rank #1 When Customers Search For You</h4>
                  <p className="text-slate-400 mb-6">
                    Dominate 'near me' searches in Warren, Detroit, Troy. Your business shows up first when customers are ready to buy.
                  </p>
                  <div className="flex items-center text-orange-600 group-hover:gap-2 transition-all">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </Card>
              </Link>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Link to="/services/social-media">
                <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-600 transition-all group">
                  <div className="text-orange-600 text-4xl mb-4">$499/month</div>
                  <h3 className="text-white mb-4 text-2xl">Social Media Growth</h3>
                  <h4 className="text-slate-300 mb-6 text-xl">Build Authority & Stay Top-of-Mind</h4>
                  <p className="text-slate-400 mb-6">
                    4 platforms. Daily posts + stories. Professional content. Your brand everywhere customers look.
                  </p>
                  <div className="flex items-center text-orange-600 group-hover:gap-2 transition-all">
                    <span>Learn More</span>
                    <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </Card>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl lg:text-5xl">Simple. Fast. Profitable.</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="text-orange-600 text-7xl mb-4">01</div>
              <h3 className="text-white mb-3 text-2xl">Free Growth Audit (15 min)</h3>
              <p className="text-slate-400 text-lg">
                We analyze your current situation and show exactly how to get more customers
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-center"
            >
              <div className="text-orange-600 text-7xl mb-4">02</div>
              <h3 className="text-white mb-3 text-2xl">We Build & Launch (1-2 weeks)</h3>
              <p className="text-slate-400 text-lg">
                Fast execution. No waiting months. You're live and getting leads quickly.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <div className="text-orange-600 text-7xl mb-4">03</div>
              <h3 className="text-white mb-3 text-2xl">Watch Your Business Grow</h3>
              <p className="text-slate-400 text-lg">
                More calls. More bookings. More revenue. We handle everything technical.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Proof/Testimonials */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">Metro Detroit Businesses Trust Us</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "John's Auto Detailing", location: "Warren, MI", quote: "Bookings doubled in 60 days", image: "https://images.unsplash.com/photo-1620584899131-a5ff5f8fbb03?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRvJTIwZGV0YWlsaW5nJTIwY2FyfGVufDF8fHx8MTc2MjAyMzYwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" },
              { name: "Detroit HVAC Pro", location: "Detroit, MI", quote: "Phone rings off the hook now", image: "https://images.unsplash.com/photo-1599463698367-11cb72775b67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVtYmVyJTIwcmVwYWlyfGVufDF8fHx8MTc2MjAxMjI3NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" },
              { name: "Troy Auto Repair", location: "Troy, MI", quote: "Schedule booked 3 weeks out", image: "https://images.unsplash.com/photo-1613214149922-f1809c99b414?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWNoYW5pYyUyMGdhcmFnZXxlbnwxfHx8fDE3NjIwMjM2MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" },
            ].map((testimonial) => (
              <Card key={testimonial.name} className="bg-slate-900 border-slate-800 overflow-hidden group cursor-pointer hover:border-orange-600 transition-colors">
                <div className="relative aspect-video">
                  <ImageWithFallback
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center group-hover:bg-slate-950/60 transition-colors">
                    <PlayCircle className="w-20 h-20 text-white opacity-80 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-sm rounded-lg p-3">
                    <div className="text-orange-600 text-sm">{testimonial.quote}</div>
                  </div>
                </div>
                <div className="p-4">
                  <div className="text-white">{testimonial.name}</div>
                  <div className="text-slate-500 text-sm">{testimonial.location}</div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Local SEO Section */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-6 text-4xl lg:text-5xl">Found By Customers Across Metro Detroit</h2>
            <p className="text-slate-300 text-xl max-w-3xl mx-auto">
              When someone in Warren searches "auto detailer near me" or Detroit searches "emergency plumber", <span className="text-orange-600">YOUR business shows up first.</span> That's what we do.
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <div className="bg-slate-900 border-2 border-slate-800 rounded-2xl p-6">
              <div className="flex items-center gap-4 bg-slate-800 rounded-lg px-6 py-4 mb-6">
                <span className="text-slate-500">🔍</span>
                <span className="text-slate-300 text-lg flex-1">plumber near me Warren MI</span>
              </div>
              
              <div className="space-y-3">
                <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white rounded-lg p-6 border-2 border-orange-500">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-2xl">YOUR BUSINESS</div>
                    <Badge className="bg-white text-orange-600">#1</Badge>
                  </div>
                  <div className="text-orange-100 text-sm">Warren, MI • 4.9★ (127 reviews)</div>
                </div>
                
                <div className="bg-slate-800 text-slate-500 rounded-lg p-4 opacity-50">
                  <div>Competitor Business</div>
                  <div className="text-xs">Warren, MI • 4.2★</div>
                </div>
                
                <div className="bg-slate-800 text-slate-500 rounded-lg p-4 opacity-30">
                  <div>Another Competitor</div>
                  <div className="text-xs">Detroit, MI • 3.8★</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 bg-gradient-to-br from-orange-600/20 via-slate-950 to-slate-950" id="contact">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-white mb-8 text-5xl lg:text-7xl">Ready For More Customers?</h2>
            <p className="text-2xl text-slate-300 mb-12">
              Free growth audit. No pressure. Just a clear plan to grow.
            </p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-2xl px-16 py-10 shadow-2xl shadow-orange-600/30 mb-8">
              Get Your Free Growth Plan
            </Button>
            <div className="text-slate-400 text-xl">
              Or call us:{' '}
              <a href="tel:5865550123" className="text-orange-600 hover:text-orange-500 transition-colors">
                (586) 555-0123
              </a>
            </div>
            <div className="text-slate-500 mt-4">
              Warren, MI • Serving All Metro Detroit
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
