import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Send, Check, DollarSign } from 'lucide-react';
import { useState } from 'react';

export function QuotePage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    website: '',
    services: [] as string[],
    budget: '',
    projectDetails: '',
    timeline: ''
  });

  const services = [
    { 
      id: 'website', 
      name: 'Website Design & Development', 
      price: '$2,500 one-time',
      description: 'Custom website that converts visitors into customers'
    },
    { 
      id: 'ecommerce', 
      name: 'E-Commerce Website', 
      price: '$2,500+ one-time',
      description: 'Full online store with payment processing'
    },
    { 
      id: 'booking', 
      name: 'Booking System Website', 
      price: '$2,500+ one-time',
      description: 'Online scheduling and appointment booking'
    },
    { 
      id: 'seo', 
      name: 'Local SEO', 
      price: '$1,000/month',
      description: 'Rank #1 on Google for local searches'
    },
    { 
      id: 'social', 
      name: 'Social Media Management', 
      price: '$499/month',
      description: 'Daily posts + stories on 4 platforms'
    }
  ];

  const handleServiceToggle = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter(s => s !== serviceId)
        : [...prev.services, serviceId]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Quote request:', formData);
    alert('Thank you! We\'ll send you a detailed quote within 24 hours.');
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Get Your Free Quote
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Tell us about your project and we'll send you a detailed proposal with transparent pricing and timeline. No pressure, no obligation.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quote Form */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-slate-900 border-slate-800 p-8 lg:p-12">
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Contact Information */}
                  <div>
                    <h2 className="text-white mb-6 text-2xl">Your Information</h2>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="name" className="text-slate-300 mb-2 block">
                          Your Name *
                        </Label>
                        <Input
                          id="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="John Smith"
                        />
                      </div>
                      <div>
                        <Label htmlFor="company" className="text-slate-300 mb-2 block">
                          Company Name *
                        </Label>
                        <Input
                          id="company"
                          type="text"
                          required
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="Your Business"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6 mt-6">
                      <div>
                        <Label htmlFor="email" className="text-slate-300 mb-2 block">
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="john@company.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone" className="text-slate-300 mb-2 block">
                          Phone Number *
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="(586) 555-0123"
                        />
                      </div>
                    </div>

                    <div className="mt-6">
                      <Label htmlFor="website" className="text-slate-300 mb-2 block">
                        Current Website (if any)
                      </Label>
                      <Input
                        id="website"
                        type="url"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                        placeholder="https://yourwebsite.com"
                      />
                    </div>
                  </div>

                  {/* Service Selection */}
                  <div>
                    <h2 className="text-white mb-4 text-2xl">What Services Do You Need? *</h2>
                    <p className="text-slate-400 mb-6">Select all that apply</p>
                    <div className="space-y-4">
                      {services.map((service) => (
                        <div
                          key={service.id}
                          onClick={() => handleServiceToggle(service.id)}
                          className={`border-2 rounded-xl p-6 cursor-pointer transition-all ${
                            formData.services.includes(service.id)
                              ? 'border-orange-600 bg-orange-600/10'
                              : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-start gap-4">
                            <div className="mt-1">
                              <Checkbox
                                checked={formData.services.includes(service.id)}
                                onCheckedChange={() => handleServiceToggle(service.id)}
                                className="border-slate-600"
                              />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between gap-4 mb-2">
                                <h3 className="text-white text-lg">{service.name}</h3>
                                <div className="text-orange-600 font-semibold whitespace-nowrap">
                                  {service.price}
                                </div>
                              </div>
                              <p className="text-slate-400">{service.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Project Details */}
                  <div>
                    <h2 className="text-white mb-6 text-2xl">Project Details</h2>
                    
                    <div className="mb-6">
                      <Label htmlFor="budget" className="text-slate-300 mb-2 block">
                        Your Budget Range
                      </Label>
                      <select
                        id="budget"
                        value={formData.budget}
                        onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                        className="w-full bg-slate-800 border-2 border-slate-700 text-white rounded-lg px-4 py-3 focus:border-orange-600 focus:outline-none"
                      >
                        <option value="">Select a budget range</option>
                        <option value="under-5k">Under $5,000</option>
                        <option value="5k-10k">$5,000 - $10,000</option>
                        <option value="10k-20k">$10,000 - $20,000</option>
                        <option value="20k-plus">$20,000+</option>
                        <option value="not-sure">Not sure yet</option>
                      </select>
                    </div>

                    <div className="mb-6">
                      <Label htmlFor="timeline" className="text-slate-300 mb-2 block">
                        When Do You Need This?
                      </Label>
                      <select
                        id="timeline"
                        value={formData.timeline}
                        onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                        className="w-full bg-slate-800 border-2 border-slate-700 text-white rounded-lg px-4 py-3 focus:border-orange-600 focus:outline-none"
                      >
                        <option value="">Select a timeline</option>
                        <option value="asap">ASAP (1-2 weeks)</option>
                        <option value="1-month">Within 1 month</option>
                        <option value="2-3-months">2-3 months</option>
                        <option value="flexible">Flexible</option>
                      </select>
                    </div>

                    <div>
                      <Label htmlFor="projectDetails" className="text-slate-300 mb-2 block">
                        Tell Us About Your Project *
                      </Label>
                      <Textarea
                        id="projectDetails"
                        required
                        value={formData.projectDetails}
                        onChange={(e) => setFormData({ ...formData, projectDetails: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 min-h-[200px]"
                        placeholder="What are your goals? What challenges are you facing? What does success look like for you?"
                      />
                    </div>
                  </div>

                  {/* Pricing Info */}
                  <div className="bg-orange-600/10 border-2 border-orange-600/30 rounded-xl p-6">
                    <div className="flex items-start gap-4">
                      <DollarSign className="w-8 h-8 text-orange-600 flex-shrink-0" />
                      <div>
                        <h3 className="text-white text-lg mb-2">Transparent Pricing</h3>
                        <ul className="text-slate-300 space-y-1 text-sm">
                          <li>• Website Design: $2,500 one-time</li>
                          <li>• Local SEO: $1,000/month</li>
                          <li>• Social Media: $499/month</li>
                          <li>• No hidden fees. No long-term contracts.</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white text-xl py-8"
                  >
                    <Send className="w-6 h-6 mr-2" />
                    Get Your Free Quote
                  </Button>

                  <div className="text-center space-y-2">
                    <p className="text-slate-400">
                      We'll send you a detailed proposal within 24 hours
                    </p>
                    <div className="flex items-center justify-center gap-6 text-sm text-slate-500">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-orange-600" />
                        No obligation
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-orange-600" />
                        No pressure
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-orange-600" />
                        Free consultation
                      </div>
                    </div>
                  </div>
                </form>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Call Option */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-white mb-4 text-3xl">Prefer To Talk?</h2>
              <p className="text-slate-300 mb-8">
                Call us directly for a free 15-minute consultation
              </p>
              <a href="tel:5863658389">
                <Button size="lg" variant="outline" className="border-2 border-orange-600 text-orange-600 hover:bg-orange-600 hover:text-white text-xl px-10 py-8">
                  Call (586) 365-8389
                </Button>
              </a>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
