import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Check, Code, Search, Share2, ArrowRight, TrendingUp } from 'lucide-react';

export function ServicesPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Services Built For One Thing: Getting You More Customers
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Website design, local SEO, and social media management for Metro Detroit service businesses. Every service focused on filling your pipeline with qualified leads.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid lg:grid-cols-3 gap-8"
          >
            {/* Website Design */}
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-600 transition-colors">
                <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <Code className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-white mb-4 text-2xl">Custom Websites That Convert</h3>
                
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Built to turn visitors into customers</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Mobile-optimized for on-the-go searchers</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Fast-loading (under 3 seconds)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Online booking systems built-in</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>SEO-ready from day one</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Easy to update (or we do it)</span>
                  </li>
                </ul>

                <div className="text-orange-600 text-4xl mb-4">$2,500 one-time</div>
                
                <Link to="/services/website">
                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                    Learn More
                  </Button>
                </Link>
              </Card>
            </motion.div>

            {/* Local SEO */}
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-orange-600 p-8 h-full relative">
                <div className="absolute top-4 right-4 bg-orange-600 text-white text-xs px-3 py-1 rounded-full">
                  MOST POPULAR
                </div>
                <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <Search className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-white mb-4 text-2xl">Rank #1 in Your Area</h3>
                
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Dominate 'near me' searches</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Show up before competitors</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Google Business Profile optimization</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Local keyword domination</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Monthly ranking reports</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>More organic leads every month</span>
                  </li>
                </ul>

                <div className="text-orange-600 text-4xl mb-4">$1,000/month</div>
                
                <Link to="/services/seo">
                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                    Learn More
                  </Button>
                </Link>
              </Card>
            </motion.div>

            {/* Social Media */}
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-600 transition-colors">
                <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <Share2 className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-white mb-4 text-2xl">Social Media That Builds Authority</h3>
                
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Daily posts + stories on 4 platforms</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Professional graphics & content</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>SEO-optimized captions & hashtags</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Engagement with your audience</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Consistent brand presence</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                    <span>Turn followers into customers</span>
                  </li>
                </ul>

                <div className="text-orange-600 text-4xl mb-4">$499/month</div>
                
                <Link to="/services/social-media">
                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                    Learn More
                  </Button>
                </Link>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Why These Services */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-6 text-4xl">Everything Works Together To Grow Your Business</h2>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-slate-900 border-2 border-slate-800 rounded-2xl p-8">
              <div className="flex flex-col md:flex-row items-center justify-center gap-8 text-center">
                <div className="flex-1">
                  <div className="bg-orange-600/10 w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Code className="w-10 h-10 text-orange-600" />
                  </div>
                  <div className="text-white text-xl mb-2">Website</div>
                  <div className="text-slate-400">Foundation</div>
                </div>
                
                <ArrowRight className="w-8 h-8 text-orange-600 rotate-90 md:rotate-0" />
                
                <div className="flex-1">
                  <div className="bg-orange-600/10 w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Search className="w-10 h-10 text-orange-600" />
                  </div>
                  <div className="text-white text-xl mb-2">SEO</div>
                  <div className="text-slate-400">Traffic</div>
                </div>
                
                <ArrowRight className="w-8 h-8 text-orange-600 rotate-90 md:rotate-0" />
                
                <div className="flex-1">
                  <div className="bg-orange-600/10 w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Share2 className="w-10 h-10 text-orange-600" />
                  </div>
                  <div className="text-white text-xl mb-2">Social Media</div>
                  <div className="text-slate-400">Authority</div>
                </div>
                
                <div className="text-orange-600 text-3xl font-bold">=</div>
                
                <div className="flex-1">
                  <div className="bg-gradient-to-br from-orange-600 to-orange-700 w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-10 h-10 text-white" />
                  </div>
                  <div className="text-white text-xl mb-2">MORE CUSTOMERS</div>
                </div>
              </div>
              
              <p className="text-slate-300 text-center mt-8 text-lg">
                Your website converts. SEO brings you traffic. Social media builds trust. <span className="text-orange-600">Combined = a customer-generating machine.</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Local Focus */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-white mb-6 text-4xl">Every Service Optimized For Metro Detroit</h2>
              <p className="text-slate-300 text-xl mb-8">
                We don't do generic national strategies. Everything is tailored for Warren, Detroit, Troy, and Metro Detroit customers searching locally.
              </p>
              <div className="bg-slate-900 border-2 border-orange-600/30 rounded-xl p-8">
                <div className="text-orange-600 text-lg mb-4">Your business will rank for searches like:</div>
                <div className="space-y-2 text-slate-300">
                  <div>"auto detailer near me Warren"</div>
                  <div>"emergency plumber Detroit MI"</div>
                  <div>"hvac repair Troy Michigan"</div>
                  <div>"best mechanic Sterling Heights"</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ROI Section */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">What You Actually Get</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 text-center">
              <div className="text-6xl text-orange-600 mb-4">3-5×</div>
              <h3 className="text-white text-2xl mb-3">Return On Investment</h3>
              <p className="text-slate-400">
                Every dollar invested returns 3-5X in new customer revenue
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 text-center">
              <div className="text-6xl text-orange-600 mb-4">10-50</div>
              <h3 className="text-white text-2xl mb-3">New Customers Per Month</h3>
              <p className="text-slate-400">
                Consistent flow of qualified leads ready to buy
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8 text-center">
              <div className="text-6xl text-orange-600 mb-4">90</div>
              <h3 className="text-white text-2xl mb-3">Days to Full Schedule</h3>
              <p className="text-slate-400">
                Most clients fully booked within 3 months
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-600/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6 text-4xl lg:text-5xl">Ready To Grow?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Get a free growth plan showing exactly how we'll get you more customers.
            </p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-12 py-8">
              Get Your Free Growth Plan
            </Button>
            <div className="text-slate-400 mt-4">
              Or call:{' '}
              <a href="tel:5865550123" className="text-orange-600 hover:text-orange-500">
                (586) 555-0123
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
