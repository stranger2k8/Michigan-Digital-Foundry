import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Check, 
  Share2, 
  Users, 
  TrendingUp, 
  MessageSquare, 
  FileText, 
  Hash,
  BarChart3,
  Instagram,
  Facebook,
  Linkedin
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

export function SocialMediaPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 via-slate-950 to-slate-950" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0icmdiYSgyNTUsMTIwLDAsLjAzKSIvPjwvZz48L3N2Zz4=')] opacity-20" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6">
                Stop Posting Into The Void. Start Building Authority.
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Consistent, professional social media content that builds trust, drives engagement, and turns followers into customers.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
                  Get Free Content Strategy
                </Button>
                <Button size="lg" variant="outline" className="border-slate-700 text-white hover:bg-slate-800">
                  See Our Content
                </Button>
              </div>
              
              {/* Trust Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-slate-300">
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">Daily Posts</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">Full Content Creation</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">Real Engagement</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why It Matters */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Why Social Media Matters for Service Businesses</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Your potential customers are checking you out on social before they ever pick up the phone.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">78%</div>
                <p className="text-slate-300">
                  of customers check social media before making a purchase
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">+67%</div>
                <p className="text-slate-300">
                  more leads from consistent social media activity
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">4.2×</div>
                <p className="text-slate-300">
                  higher trust in businesses with active social presence
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">What's Included</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Everything you need to build a professional social media presence that drives real business results.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Content Strategy</h3>
                <p className="text-slate-400 text-sm">
                  Custom content calendar aligned with your business goals and audience.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Share2 className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Graphic Design</h3>
                <p className="text-slate-400 text-sm">
                  Professional graphics that stop the scroll and reinforce your brand.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Copywriting</h3>
                <p className="text-slate-400 text-sm">
                  Engaging captions that showcase your expertise and drive action.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Hash className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Hashtag Research</h3>
                <p className="text-slate-400 text-sm">
                  Strategic hashtags to maximize reach and get found by local customers.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">4-5 Posts Per Week</h3>
                <p className="text-slate-400 text-sm">
                  Consistent posting schedule to keep you top of mind with your audience.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Instagram className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Stories & Reels</h3>
                <p className="text-slate-400 text-sm">
                  Dynamic story content and short-form videos to boost engagement.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Community Management</h3>
                <p className="text-slate-400 text-sm">
                  We engage with comments and messages to build relationships.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Monthly Reports</h3>
                <p className="text-slate-400 text-sm">
                  Track growth, engagement, and ROI with clear monthly analytics.
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Content Examples */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Content That Converts</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Professional posts designed to educate, engage, and convert your audience.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto"
          >
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <motion.div key={item} variants={fadeInUp}>
                <Card className="bg-slate-900 border-slate-800 overflow-hidden group hover:border-orange-500 transition-colors">
                  <div className="aspect-square bg-gradient-to-br from-orange-500/20 to-slate-800 flex items-center justify-center relative overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1611926653458-09294b3142bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjBtZWRpYSUyMGNvbnRlbnR8ZW58MXx8fHwxNzYxOTU2MTEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt={`Social media post example ${item}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="p-4">
                    <div className="text-sm text-slate-400">
                      {item % 3 === 0 ? 'Educational Post' : item % 2 === 0 ? 'Before/After' : 'Testimonial'}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Packages */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Social Media Packages</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Choose the package that fits your goals. All plans include full content creation and management.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-500 transition-colors">
                <h3 className="text-white mb-2">Essential</h3>
                <div className="text-3xl text-orange-500 mb-1">$1,500</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">3-4 Posts Per Week</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">1 Platform (Facebook or Instagram)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Custom Graphics & Copy</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Hashtag Strategy</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Monthly Analytics</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full border-slate-700 text-white hover:bg-slate-800">
                  Get Started
                </Button>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-orange-500 p-8 h-full relative overflow-hidden">
                <Badge className="absolute top-4 right-4 bg-orange-600 text-white">Most Popular</Badge>
                <h3 className="text-white mb-2">Professional</h3>
                <div className="text-3xl text-orange-500 mb-1">$2,500</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">4-5 Posts Per Week</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">2 Platforms</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Stories & Reels (8-12/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Community Engagement</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Content Calendar Access</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Detailed Monthly Reports</span>
                  </li>
                </ul>
                <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                  Get Started
                </Button>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-500 transition-colors">
                <h3 className="text-white mb-2">Premium</h3>
                <div className="text-3xl text-orange-500 mb-1">$4,000</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Daily Posts</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">3+ Platforms</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Stories & Reels (15-20/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Full Community Management</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Influencer Outreach</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Paid Ads Management</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full border-slate-700 text-white hover:bg-slate-800">
                  Get Started
                </Button>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Results */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Real Growth. Real Results.</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              See how we've helped businesses build authority and grow their following.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8">
                <Badge className="bg-orange-500/10 text-orange-500 mb-3">Home Services</Badge>
                <h3 className="text-white mb-4">Elite Plumbing</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">280 → 2,400</div>
                    <div className="text-slate-400 text-sm">Followers</div>
                  </div>
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">+340%</div>
                    <div className="text-slate-400 text-sm">Engagement Rate</div>
                  </div>
                </div>
                <p className="text-slate-400 text-sm">
                  "Our social media went from crickets to constant engagement. Customers actually reference our posts when they call!" - Tom R.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8">
                <Badge className="bg-orange-500/10 text-orange-500 mb-3">Health & Wellness</Badge>
                <h3 className="text-white mb-4">Thrive Fitness Studio</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">450 → 3,800</div>
                    <div className="text-slate-400 text-sm">Followers</div>
                  </div>
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">+67%</div>
                    <div className="text-slate-400 text-sm">New Memberships</div>
                  </div>
                </div>
                <p className="text-slate-400 text-sm">
                  "We've become the go-to fitness brand in our area. Our social presence has completely transformed how people see us." - Jessica M.
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Frequently Asked Questions</h2>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Do you handle everything or do I need to create content?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  We handle everything — strategy, design, writing, posting, and engagement. You just approve the content calendar and watch your presence grow. We may occasionally ask for photos or feedback, but we do the heavy lifting.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Which platforms should I be on?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  It depends on your business and audience. Most service businesses do well on Facebook and Instagram. Professional services often benefit from LinkedIn. We'll recommend the best platforms during your strategy session.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  How long before I see results?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  You'll see growth in followers and engagement within the first month. Lead generation typically picks up within 2-3 months as your authority builds and your audience grows.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Can I review posts before they go live?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  Absolutely. We provide a content calendar for your review and approval before any posts go live. You have final say on everything.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Do I need to buy ads separately?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  Our Essential and Professional packages focus on organic growth. The Premium package includes paid ads management and ad spend optimization. We can add paid ads to any package for an additional fee.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-900/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6">Ready To Build Real Authority?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Get a free content strategy session and see how we can transform your social media presence.
            </p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
              Get Free Social Strategy
            </Button>
            <p className="text-sm text-slate-500 mt-4">
              No commitment. Just a clear plan for social media success.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
