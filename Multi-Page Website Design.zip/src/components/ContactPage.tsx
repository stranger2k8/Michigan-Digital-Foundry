import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { useState } from 'react';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this would send to your backend
    console.log('Form submitted:', formData);
    alert('Thank you! We\'ll get back to you within 24 hours.');
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Let's Get You More Customers
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Ready to dominate your local market? Fill out the form below or give us a call. We typically respond within 2 hours.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12 max-w-6xl mx-auto">
            {/* Contact Info Cards */}
            <div className="lg:col-span-1 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <Card className="bg-slate-900 border-slate-800 p-6">
                  <div className="bg-orange-600/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                    <Phone className="w-7 h-7 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-2 text-xl">Call Us</h3>
                  <a href="tel:5863658389" className="text-orange-600 hover:text-orange-500 transition-colors text-lg">
                    (586) 365-8389
                  </a>
                  <p className="text-slate-400 text-sm mt-2">
                    Mon-Fri: 8am-6pm<br/>
                    Sat: 9am-2pm
                  </p>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-slate-900 border-slate-800 p-6">
                  <div className="bg-orange-600/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                    <Mail className="w-7 h-7 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-2 text-xl">Email Us</h3>
                  <a href="mailto:info.michigandigitalfoundry@gmail.com" className="text-orange-600 hover:text-orange-500 transition-colors break-all">
                    info.michigandigitalfoundry@gmail.com
                  </a>
                  <p className="text-slate-400 text-sm mt-2">
                    We respond within 24 hours
                  </p>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <Card className="bg-slate-900 border-slate-800 p-6">
                  <div className="bg-orange-600/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                    <MapPin className="w-7 h-7 text-orange-600" />
                  </div>
                  <h3 className="text-white mb-2 text-xl">Visit Us</h3>
                  <p className="text-slate-300">
                    Warren, Michigan
                  </p>
                  <p className="text-slate-400 text-sm mt-2">
                    Serving all Metro Detroit
                  </p>
                </Card>
              </motion.div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <Card className="bg-slate-900 border-slate-800 p-8">
                  <h2 className="text-white mb-6 text-3xl">Send Us A Message</h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="name" className="text-slate-300 mb-2 block">
                          Your Name *
                        </Label>
                        <Input
                          id="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="John Smith"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email" className="text-slate-300 mb-2 block">
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="john@company.com"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="phone" className="text-slate-300 mb-2 block">
                          Phone Number *
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="(586) 555-0123"
                        />
                      </div>
                      <div>
                        <Label htmlFor="company" className="text-slate-300 mb-2 block">
                          Company Name
                        </Label>
                        <Input
                          id="company"
                          type="text"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                          placeholder="Your Business"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="message" className="text-slate-300 mb-2 block">
                        How Can We Help? *
                      </Label>
                      <Textarea
                        id="message"
                        required
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 min-h-[150px]"
                        placeholder="Tell us about your business and what you're looking to achieve..."
                      />
                    </div>

                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full bg-orange-600 hover:bg-orange-700 text-white text-lg"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Send Message
                    </Button>

                    <p className="text-slate-400 text-sm text-center">
                      We typically respond within 2 hours during business hours
                    </p>
                  </form>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-white mb-8 text-3xl">Prefer A Different Way?</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                  <Phone className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="text-white mb-3 text-xl">Schedule A Call</h3>
                  <p className="text-slate-400 mb-6">
                    Book a 30-minute strategy session to discuss your goals
                  </p>
                  <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                    Schedule Now
                  </Button>
                </Card>

                <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                  <Mail className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                  <h3 className="text-white mb-3 text-xl">Get A Free Quote</h3>
                  <p className="text-slate-400 mb-6">
                    Tell us about your project and get a detailed proposal
                  </p>
                  <a href="/quote">
                    <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                      Request Quote
                    </Button>
                  </a>
                </Card>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
