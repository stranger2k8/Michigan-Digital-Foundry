import { motion } from 'motion/react';
import { Card } from './ui/card';

export function TermsPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Terms of Service
              </h1>
              <p className="text-xl text-slate-300 mb-4">
                Last Updated: November 1, 2025
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-900 border-slate-800 p-8 lg:p-12">
              <div className="prose prose-invert prose-slate max-w-none">
                <div className="space-y-8 text-slate-300">
                  <section>
                    <h2 className="text-white text-2xl mb-4">1. Acceptance of Terms</h2>
                    <p>
                      Welcome to Michigan Digital Foundry. By accessing our website, using our services, or engaging with us, you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use our website or services.
                    </p>
                    <p className="mt-4">
                      These Terms constitute a legally binding agreement between you and Michigan Digital Foundry ("we," "our," or "us").
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">2. Services</h2>
                    <p>Michigan Digital Foundry provides digital marketing services, including but not limited to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Website design and development</li>
                      <li>E-commerce website development</li>
                      <li>Booking system integration</li>
                      <li>Local SEO services</li>
                      <li>Social media management</li>
                      <li>Digital marketing consulting</li>
                    </ul>
                    <p className="mt-4">
                      Specific services, deliverables, timelines, and pricing will be outlined in individual service agreements or proposals.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">3. Service Agreements</h2>
                    <h3 className="text-white text-xl mb-3">3.1 Proposals and Quotes</h3>
                    <p>
                      All quotes and proposals are valid for 30 days from the date of issue unless otherwise specified. Pricing is subject to change based on project scope modifications.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">3.2 Payment Terms</h3>
                    <ul className="list-disc pl-6 space-y-2">
                      <li><strong>Website Projects:</strong> 50% deposit required to begin work, 50% due upon completion</li>
                      <li><strong>Monthly Services (SEO/Social Media):</strong> Payment due monthly in advance</li>
                      <li>Late payments may result in service suspension and late fees of 1.5% per month</li>
                      <li>All prices are in USD</li>
                    </ul>

                    <h3 className="text-white text-xl mb-3 mt-6">3.3 Refund Policy</h3>
                    <p>
                      Deposits are non-refundable once work has commenced. For monthly services, you may cancel with 30 days written notice. No refunds for partial months.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">4. Client Responsibilities</h2>
                    <p>As a client, you agree to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Provide timely and accurate information, content, and feedback</li>
                      <li>Respond to requests for input within agreed timeframes</li>
                      <li>Provide necessary access to accounts, platforms, and resources</li>
                      <li>Ensure all content you provide does not infringe on third-party rights</li>
                      <li>Review and approve deliverables within specified timeframes</li>
                      <li>Make timely payments according to agreed terms</li>
                    </ul>
                    <p className="mt-4">
                      Delays caused by failure to meet these responsibilities may result in project delays and additional fees.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">5. Intellectual Property</h2>
                    <h3 className="text-white text-xl mb-3">5.1 Ownership</h3>
                    <p>
                      Upon full payment, you own the final deliverables created specifically for you (website design, custom graphics, content). However, we retain ownership of:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Pre-existing materials and tools</li>
                      <li>General methodologies and processes</li>
                      <li>Templates and frameworks</li>
                      <li>Source code for proprietary tools</li>
                    </ul>

                    <h3 className="text-white text-xl mb-3 mt-6">5.2 Portfolio Rights</h3>
                    <p>
                      We reserve the right to display completed work in our portfolio and marketing materials unless you request otherwise in writing.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">5.3 Third-Party Materials</h3>
                    <p>
                      Some projects may include third-party resources (stock photos, fonts, plugins) that have their own licensing terms. You are responsible for maintaining these licenses.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">6. Warranties and Disclaimers</h2>
                    <h3 className="text-white text-xl mb-3">6.1 Our Warranties</h3>
                    <p>We warrant that:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Services will be performed with reasonable skill and care</li>
                      <li>Work will be original or properly licensed</li>
                      <li>We have the right to provide the services</li>
                    </ul>

                    <h3 className="text-white text-xl mb-3 mt-6">6.2 Disclaimer</h3>
                    <p>
                      EXCEPT AS EXPRESSLY PROVIDED, ALL SERVICES ARE PROVIDED "AS IS" WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED. We do not guarantee specific results, rankings, traffic, or revenue. Digital marketing results depend on many factors beyond our control.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">7. Limitation of Liability</h2>
                    <p>
                      TO THE MAXIMUM EXTENT PERMITTED BY LAW, MICHIGAN DIGITAL FOUNDRY SHALL NOT BE LIABLE FOR:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Indirect, incidental, consequential, or punitive damages</li>
                      <li>Loss of profits, revenue, data, or business opportunities</li>
                      <li>Damages exceeding the amount paid for services in the preceding 12 months</li>
                    </ul>
                    <p className="mt-4">
                      Some jurisdictions do not allow limitation of certain damages, so these limitations may not apply to you.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">8. Termination</h2>
                    <h3 className="text-white text-xl mb-3">8.1 By Client</h3>
                    <p>
                      You may terminate services with 30 days written notice. For website projects, termination fees may apply based on work completed. Monthly services can be canceled with 30 days notice; no refunds for current month.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">8.2 By Michigan Digital Foundry</h3>
                    <p>
                      We may terminate services immediately if you:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Fail to make payments</li>
                      <li>Breach these Terms</li>
                      <li>Engage in abusive or illegal behavior</li>
                      <li>Provide false or misleading information</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">9. Confidentiality</h2>
                    <p>
                      Both parties agree to keep confidential information private and use it only for the purposes of the service relationship. This obligation continues for 2 years after the relationship ends.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">10. Indemnification</h2>
                    <p>
                      You agree to indemnify and hold Michigan Digital Foundry harmless from any claims, damages, or expenses arising from:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Content or materials you provide</li>
                      <li>Your use of our services</li>
                      <li>Your violation of these Terms</li>
                      <li>Your violation of any third-party rights</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">11. Changes to Services and Terms</h2>
                    <p>
                      We reserve the right to modify our services, pricing, and these Terms at any time. Changes will be posted on our website with an updated date. Continued use of services after changes constitutes acceptance.
                    </p>
                    <p className="mt-4">
                      For active projects or ongoing services, we will notify you of material changes via email.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">12. Dispute Resolution</h2>
                    <h3 className="text-white text-xl mb-3">12.1 Informal Resolution</h3>
                    <p>
                      Before pursuing formal legal action, parties agree to attempt to resolve disputes through good-faith negotiation for at least 30 days.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">12.2 Governing Law</h3>
                    <p>
                      These Terms are governed by the laws of the State of Michigan, without regard to conflict of law principles. Any legal action must be brought in the courts of Macomb County, Michigan.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">13. General Provisions</h2>
                    <h3 className="text-white text-xl mb-3">13.1 Entire Agreement</h3>
                    <p>
                      These Terms, together with any service-specific agreements, constitute the entire agreement between parties and supersede all prior agreements.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">13.2 Severability</h3>
                    <p>
                      If any provision is found unenforceable, the remaining provisions will continue in full force.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">13.3 No Waiver</h3>
                    <p>
                      Failure to enforce any right or provision does not constitute a waiver of that right or provision.
                    </p>

                    <h3 className="text-white text-xl mb-3 mt-6">13.4 Assignment</h3>
                    <p>
                      You may not assign your rights or obligations without our written consent. We may assign our rights and obligations to any party.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">14. Contact Information</h2>
                    <p>For questions about these Terms, please contact us:</p>
                    <div className="mt-4 bg-slate-800 rounded-lg p-6">
                      <p className="mb-2"><strong className="text-white">Michigan Digital Foundry</strong></p>
                      <p>Warren, Michigan</p>
                      <p>Phone: <a href="tel:5863658389" className="text-orange-600 hover:text-orange-500">(586) 365-8389</a></p>
                      <p>Email: <a href="mailto:info.michigandigitalfoundry@gmail.com" className="text-orange-600 hover:text-orange-500">info.michigandigitalfoundry@gmail.com</a></p>
                    </div>
                  </section>

                  <section className="pt-8 border-t border-slate-700">
                    <p className="text-sm text-slate-500">
                      By using our website or services, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.
                    </p>
                  </section>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
