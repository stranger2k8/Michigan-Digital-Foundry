import { Link } from 'react-router-dom';
import { Anvil, Phone, Mail, MapPin, Clock } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Logo & Description */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Anvil className="w-8 h-8 text-orange-600" />
              <div className="flex flex-col leading-none">
                <span className="text-white">Michigan Digital Foundry</span>
                <span className="text-orange-600 text-xs">Warren, MI</span>
              </div>
            </Link>
            <p className="text-sm text-slate-400">
              Digital marketing for Metro Detroit businesses. More customers. More revenue. Guaranteed.
            </p>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/services/website" className="hover:text-orange-600 transition-colors">
                  Website Design - $2,500
                </Link>
              </li>
              <li>
                <Link to="/services/seo" className="hover:text-orange-600 transition-colors">
                  Local SEO - $1,000/month
                </Link>
              </li>
              <li>
                <Link to="/services/social-media" className="hover:text-orange-600 transition-colors">
                  Social Media - $499/month
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-orange-600 transition-colors">
                  View All Services →
                </Link>
              </li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h3 className="text-white mb-4">Service Areas</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Warren, MI</li>
              <li>Detroit, MI</li>
              <li>Troy, MI</li>
              <li>Sterling Heights, MI</li>
              <li>Royal Oak, MI</li>
              <li>Macomb County</li>
              <li>Oakland County</li>
              <li>Wayne County</li>
              <li className="pt-2">
                <span className="text-orange-600">All Metro Detroit</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                <div>
                  <div>Warren, Michigan</div>
                  <div className="text-slate-500">Serving All Metro Detroit</div>
                </div>
              </li>
              <li>
                <a href="tel:5863658389" className="flex items-center gap-2 hover:text-orange-600 transition-colors">
                  <Phone className="w-4 h-4 text-orange-600 flex-shrink-0" />
                  (586) 365-8389
                </a>
              </li>
              <li>
                <a href="mailto:info.michigandigitalfoundry@gmail.com" className="flex items-center gap-2 hover:text-orange-600 transition-colors break-all">
                  <Mail className="w-4 h-4 text-orange-600 flex-shrink-0" />
                  info.michigandigitalfoundry@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                <div>
                  <div>Mon-Fri: 8am-6pm</div>
                  <div className="text-slate-500">Sat: 9am-2pm</div>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 text-sm text-slate-500">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p>&copy; {new Date().getFullYear()} Michigan Digital Foundry | Proudly Based in Warren, Michigan</p>
            <div className="flex gap-6">
              <Link to="/privacy" className="hover:text-orange-600 transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-orange-600 transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
