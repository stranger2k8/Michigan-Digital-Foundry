import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Target, Zap, Users, TrendingUp, Award, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Empowering Businesses To Break Through The Four Walls
              </h1>
              <p className="text-2xl text-slate-300 mb-8">
                We help local Michigan businesses go online and dominate their market — because the old way of marketing is dead.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-white mb-6 text-4xl">The Reality That Changed Everything</h2>
              <div className="space-y-6 text-slate-300 text-lg">
                <p>
                  <span className="text-orange-600 font-semibold">87% of customers</span> now search online before buying anything. They're not looking in phone books. They're not driving around looking for businesses. They're searching on Google at 11pm in their pajamas.
                </p>
                <p>
                  Yet so many great businesses in Warren, Detroit, and across Metro Detroit are still invisible online. They do amazing work, but no one can find them. Their competitors with worse service but better websites are stealing their customers.
                </p>
                <p>
                  That's not right. And that's why Michigan Digital Foundry exists.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600/30 p-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-orange-600/20 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Target className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-white text-xl mb-2">Our Mission</h3>
                      <p className="text-slate-300">
                        Help 1,000 Michigan service businesses break through their four walls and build thriving online presences
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-orange-600/20 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Zap className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-white text-xl mb-2">Our Vision</h3>
                      <p className="text-slate-300">
                        A Metro Detroit where every quality business has the online presence they deserve — and customers can easily find the best
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-orange-600/20 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Heart className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-white text-xl mb-2">Our Values</h3>
                      <p className="text-slate-300">
                        Results over vanity metrics. Transparency over smoke and mirrors. Real growth over empty promises.
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why We're Different */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-6 text-4xl">Why Businesses Choose Us</h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">
              We're not like other agencies. We actually understand what it takes to get customers.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Award className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We Have Experience</h3>
              <p className="text-slate-400">
                2+ years building websites that convert. 50+ businesses served. We know what works and why.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We've Done This Ourselves</h3>
              <p className="text-slate-400">
                Michigan Digital Foundry grew through the exact strategies we teach. We practice what we preach.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <TrendingUp className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We Master Copywriting</h3>
              <p className="text-slate-400">
                Most web designers can't write words that sell. We can. That's why our clients' websites actually convert.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We Focus On What Matters</h3>
              <p className="text-slate-400">
                We don't care about "brand awareness." We care about your phone ringing and your calendar filling up.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We Move Fast</h3>
              <p className="text-slate-400">
                2-week turnaround on websites. No waiting months. Your competitors are getting leads right now — you should be too.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Heart className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">We're Local</h3>
              <p className="text-slate-400">
                Based in Warren, MI. We understand Metro Detroit. We're invested in local business success.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* The Numbers */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">The Results Speak For Themselves</h2>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="text-6xl text-orange-600 mb-3">50+</div>
              <div className="text-slate-300 text-lg">Businesses Served</div>
            </div>
            <div className="text-center">
              <div className="text-6xl text-orange-600 mb-3">3.5X</div>
              <div className="text-slate-300 text-lg">Average ROI</div>
            </div>
            <div className="text-center">
              <div className="text-6xl text-orange-600 mb-3">95%</div>
              <div className="text-slate-300 text-lg">Client Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-6xl text-orange-600 mb-3">2023</div>
              <div className="text-slate-300 text-lg">Year Founded</div>
            </div>
          </div>
        </div>
      </section>

      {/* The Old Way Is Dead */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-gradient-to-br from-red-900/20 to-slate-900 border-red-900/30 p-10">
                <h2 className="text-white mb-6 text-3xl text-center">The Old Way Of Marketing Is Dead</h2>
                <div className="space-y-6 text-slate-300">
                  <p className="text-lg">
                    Yellow Pages? Dead. Newspaper ads? Dead. Waiting for referrals? Too slow.
                  </p>
                  <p className="text-lg">
                    Today, when someone needs a plumber at 11pm, they pull out their phone and search Google. When someone wants their car detailed, they scroll Instagram. When someone needs HVAC repair, they book online — not during business hours, but when it's convenient for them.
                  </p>
                  <p className="text-lg">
                    If you're not online, you don't exist. If your website doesn't convert, you're wasting money. If you're not ranking on Google, your competitors are eating your lunch.
                  </p>
                  <p className="text-lg text-orange-600 font-semibold">
                    The businesses that embrace this reality thrive. The ones that don't... struggle.
                  </p>
                  <p className="text-lg">
                    Which one will you be?
                  </p>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-600/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6 text-4xl lg:text-5xl">Ready To Break Through Your Four Walls?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Let's get your business online and dominating your local market
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/quote">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-10 py-8">
                  Get Free Quote
                </Button>
              </a>
              <a href="tel:5863658389">
                <Button size="lg" variant="outline" className="border-2 border-slate-700 text-white hover:bg-slate-800 text-xl px-10 py-8">
                  Call (586) 365-8389
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
