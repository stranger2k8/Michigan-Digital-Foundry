import { motion } from 'motion/react';
import { Card } from './ui/card';

export function PrivacyPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Privacy Policy
              </h1>
              <p className="text-xl text-slate-300 mb-4">
                Last Updated: November 1, 2025
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-900 border-slate-800 p-8 lg:p-12">
              <div className="prose prose-invert prose-slate max-w-none">
                <div className="space-y-8 text-slate-300">
                  <section>
                    <h2 className="text-white text-2xl mb-4">1. Introduction</h2>
                    <p>
                      Michigan Digital Foundry ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website michigandigitalfoundry.com or use our services.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">2. Information We Collect</h2>
                    <h3 className="text-white text-xl mb-3">Personal Information</h3>
                    <p>We may collect personal information that you voluntarily provide to us when you:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Fill out contact forms or request quotes</li>
                      <li>Subscribe to our newsletter or communications</li>
                      <li>Engage with our services</li>
                      <li>Contact us via phone, email, or other channels</li>
                    </ul>
                    <p className="mt-4">This information may include:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Name and business name</li>
                      <li>Email address</li>
                      <li>Phone number</li>
                      <li>Business address</li>
                      <li>Website URL</li>
                      <li>Project details and preferences</li>
                    </ul>

                    <h3 className="text-white text-xl mb-3 mt-6">Automatically Collected Information</h3>
                    <p>When you visit our website, we automatically collect certain information about your device and browsing activity, including:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>IP address</li>
                      <li>Browser type and version</li>
                      <li>Operating system</li>
                      <li>Referring website</li>
                      <li>Pages visited and time spent</li>
                      <li>Device information</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">3. How We Use Your Information</h2>
                    <p>We use the information we collect to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Respond to your inquiries and provide requested services</li>
                      <li>Send you quotes, proposals, and project updates</li>
                      <li>Communicate with you about our services</li>
                      <li>Improve our website and services</li>
                      <li>Analyze website usage and performance</li>
                      <li>Send marketing communications (with your consent)</li>
                      <li>Comply with legal obligations</li>
                      <li>Prevent fraud and maintain security</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">4. Information Sharing and Disclosure</h2>
                    <p>We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li><strong>Service Providers:</strong> With trusted third-party vendors who assist us in operating our website and delivering services (e.g., hosting providers, email services, analytics tools)</li>
                      <li><strong>Legal Requirements:</strong> When required by law, court order, or to protect our rights and safety</li>
                      <li><strong>Business Transfers:</strong> In connection with any merger, sale, or acquisition of our business</li>
                      <li><strong>With Your Consent:</strong> When you explicitly authorize us to share your information</li>
                    </ul>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">5. Cookies and Tracking Technologies</h2>
                    <p>
                      We use cookies and similar tracking technologies to enhance your experience on our website. Cookies are small data files stored on your device that help us remember your preferences and understand how you use our site.
                    </p>
                    <p className="mt-4">You can control cookies through your browser settings. However, disabling cookies may affect your ability to use certain features of our website.</p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">6. Data Security</h2>
                    <p>
                      We implement reasonable technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no internet transmission or electronic storage method is 100% secure, and we cannot guarantee absolute security.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">7. Your Rights and Choices</h2>
                    <p>You have the right to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
                      <li><strong>Correction:</strong> Request correction of inaccurate or incomplete information</li>
                      <li><strong>Deletion:</strong> Request deletion of your personal information (subject to legal obligations)</li>
                      <li><strong>Opt-Out:</strong> Unsubscribe from marketing communications at any time</li>
                      <li><strong>Object:</strong> Object to processing of your personal information for certain purposes</li>
                    </ul>
                    <p className="mt-4">
                      To exercise these rights, please contact us at info.michigandigitalfoundry@gmail.com or call (586) 365-8389.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">8. Third-Party Links</h2>
                    <p>
                      Our website may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies before providing any personal information.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">9. Children's Privacy</h2>
                    <p>
                      Our services are not directed to individuals under the age of 18. We do not knowingly collect personal information from children. If we become aware that we have collected information from a child, we will promptly delete it.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">10. Changes to This Privacy Policy</h2>
                    <p>
                      We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated "Last Updated" date. We encourage you to review this policy periodically to stay informed about how we protect your information.
                    </p>
                  </section>

                  <section>
                    <h2 className="text-white text-2xl mb-4">11. Contact Us</h2>
                    <p>If you have any questions or concerns about this Privacy Policy or our privacy practices, please contact us:</p>
                    <div className="mt-4 bg-slate-800 rounded-lg p-6">
                      <p className="mb-2"><strong className="text-white">Michigan Digital Foundry</strong></p>
                      <p>Warren, Michigan</p>
                      <p>Phone: <a href="tel:5863658389" className="text-orange-600 hover:text-orange-500">(586) 365-8389</a></p>
                      <p>Email: <a href="mailto:info.michigandigitalfoundry@gmail.com" className="text-orange-600 hover:text-orange-500">info.michigandigitalfoundry@gmail.com</a></p>
                    </div>
                  </section>

                  <section className="pt-8 border-t border-slate-700">
                    <p className="text-sm text-slate-500">
                      By using our website or services, you acknowledge that you have read and understood this Privacy Policy and agree to its terms.
                    </p>
                  </section>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
