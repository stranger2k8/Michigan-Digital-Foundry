import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Check, Phone, Zap, Calendar, MapPin, Smartphone, Globe, DollarSign, Clock, Shield, X
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

export function WebsiteDesignPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Split */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                A Website That Actually Brings You Customers
              </h1>
              <p className="text-2xl text-slate-300 mb-8 leading-relaxed">
                Forget pretty websites that sit there. We build websites that make your phone ring, fill your calendar, and grow your revenue. <span className="text-orange-600">$2,500. Built in 2 weeks. ROI guaranteed.</span>
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-10 py-8">
                  Get Started - $2,500
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-slate-700 text-white hover:bg-slate-800 text-xl px-10 py-8">
                  See Examples
                </Button>
              </div>
              
              {/* Trust Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-5 h-5 text-orange-600" />
                  <span>2-Week Delivery</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-5 h-5 text-orange-600" />
                  <span>Mobile-Optimized</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-5 h-5 text-orange-600" />
                  <span>Booking Systems Included</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-orange-600/20">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1624555130666-eb3a38b6c3b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3ZWJzaXRlJTIwZGVzaWdufGVufDF8fHx8MTc2MTg5ODIyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Website mockup"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent" />
                
                {/* Animated Elements */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.8 }}
                  className="absolute top-1/4 left-8 bg-green-500 text-white px-4 py-2 rounded-lg shadow-xl text-sm"
                >
                  <Phone className="w-4 h-4 inline mr-2" />
                  New lead!
                </motion.div>
                
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 1 }}
                  className="absolute top-1/2 right-8 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-xl text-sm"
                >
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Booked!
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Your Website Matters */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">87% Of Customers Judge Your Business By Your Website</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-slate-900 border-red-900/50 p-8 text-center">
              <X className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-white text-2xl mb-3">No Website = Zero Trust</h3>
              <p className="text-slate-400">Customers think you're out of business or unprofessional</p>
            </Card>

            <Card className="bg-slate-900 border-red-900/50 p-8 text-center">
              <X className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-white text-2xl mb-3">Slow Website = Lost Customers</h3>
              <p className="text-slate-400">They leave before it loads and call your competitor</p>
            </Card>

            <Card className="bg-slate-900 border-red-900/50 p-8 text-center">
              <X className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-white text-2xl mb-3">Hard to Book = They Call Your Competitor</h3>
              <p className="text-slate-400">No online booking means you lose after-hours leads</p>
            </Card>
          </div>
        </div>
      </section>

      {/* What Makes Us Different */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">Built For One Thing: Converting Visitors Into Customers</h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: DollarSign, title: "Conversion-Focused Design", desc: "Every button, every section designed to make visitors take action" },
              { icon: Zap, title: "Lightning Fast Loading", desc: "Under 3 seconds. Mobile-optimized. Customers don't wait" },
              { icon: Calendar, title: "Online Booking Built-In", desc: "Let customers schedule and pay 24/7. No phone tag" },
              { icon: MapPin, title: "Local SEO Ready", desc: "Optimized for Warren, Detroit, Troy searches from day one" },
              { icon: Smartphone, title: "Mobile-First", desc: "Looks perfect on phones where 78% of local searches happen" },
              { icon: Globe, title: "Easy Updates", desc: "Change prices, hours, services yourself. Or we do it free" },
            ].map((feature) => (
              <Card key={feature.title} className="bg-slate-900 border-slate-800 p-6 hover:border-orange-600 transition-colors">
                <div className="bg-orange-600/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-7 h-7 text-orange-600" />
                </div>
                <h3 className="text-white mb-2 text-xl">{feature.title}</h3>
                <p className="text-slate-400">{feature.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing - One Simple Price */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto"
          >
            <Card className="bg-gradient-to-br from-orange-600/10 to-slate-900 border-orange-600 p-10 text-center">
              <div className="text-orange-600 text-7xl mb-4">$2,500</div>
              <h3 className="text-white text-3xl mb-6">One-Time Investment. Everything Included.</h3>
              
              <div className="bg-slate-900/50 rounded-xl p-6 mb-8 text-left">
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    "Custom design",
                    "Mobile optimization",
                    "Fast hosting (first year)",
                    "SSL security",
                    "Contact forms",
                    "Google Maps",
                    "Service area pages",
                    "SEO foundation",
                    "Stock photos",
                    "1 hour training",
                    "30-day support",
                    "Booking system option"
                  ].map((item) => (
                    <div key={item} className="flex items-center gap-2 text-slate-300">
                      <Check className="w-5 h-5 text-orange-600 flex-shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-orange-600/20 border border-orange-600/30 rounded-xl p-6 mb-8">
                <div className="text-orange-600 mb-2">ROI Calculator</div>
                <div className="text-white text-2xl">Just 2-3 new customers pays for entire website</div>
              </div>

              <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-12 py-8">
                Get Started - $2,500
              </Button>
              <div className="text-slate-400 mt-4">Or get free quote first</div>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Before/After Results */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">Real Transformations. Real Revenue Growth.</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { type: "Warren Auto Detailer", before: "2 inquiries/month", after: "23 inquiries/month" },
              { type: "Detroit Plumber", before: "No online presence", after: "Phone rings 4X more" },
              { type: "Troy Mechanic", before: "DIY website", after: "+320% traffic" },
            ].map((result) => (
              <Card key={result.type} className="bg-slate-900 border-slate-800 p-8">
                <Badge className="bg-orange-600/20 text-orange-600 mb-4">{result.type}</Badge>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-red-900/20 border border-red-900/50 rounded-lg p-4">
                    <div className="text-red-500 text-xs mb-2">BEFORE</div>
                    <div className="text-white text-sm">{result.before}</div>
                  </div>
                  <div className="bg-green-900/20 border border-green-900/50 rounded-lg p-4">
                    <div className="text-green-500 text-xs mb-2">AFTER</div>
                    <div className="text-white text-sm">{result.after}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">From Zero to Live in 2 Weeks</h2>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8 max-w-5xl mx-auto">
            {[
              { day: "Day 1", title: "Strategy Call", desc: "We learn your business and goals" },
              { day: "Days 2-7", title: "Design & Build", desc: "We create your custom website" },
              { day: "Days 8-12", title: "Your Feedback", desc: "Review and request changes" },
              { day: "Days 13-14", title: "Launch + Training", desc: "Go live and learn to update" },
            ].map((step) => (
              <div key={step.day} className="text-center">
                <div className="text-orange-600 text-2xl mb-2">{step.day}</div>
                <h3 className="text-white text-xl mb-2">{step.title}</h3>
                <p className="text-slate-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-3xl">Common Questions</h2>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {[
                { q: "Do I own the website?", a: "Yes! You own 100% of your website, content, and code. No lock-in contracts or hidden fees." },
                { q: "How long does it take?", a: "Most websites are completed within 2 weeks. We don't make you wait months." },
                { q: "Can I update it myself?", a: "Yes! We provide training. Or we can update it for you - first 3 months of minor updates included." },
                { q: "What about hosting?", a: "First year of fast, secure hosting included. After that, just $20/month." },
                { q: "What if I need changes later?", a: "30 days of free revisions after launch. After that, affordable hourly rates or maintenance plans available." },
              ].map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="bg-slate-900 border-slate-800 rounded-lg px-6">
                  <AccordionTrigger className="text-white hover:text-orange-600">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-slate-400">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-600/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6 text-5xl">Ready For A Website That Brings You Customers?</h2>
            <p className="text-xl text-slate-300 mb-8">
              $2,500. 2 weeks. Phone starts ringing.
            </p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-2xl px-12 py-10">
              Get Started - $2,500
            </Button>
            <div className="text-slate-400 mt-4">
              Or call: <a href="tel:5865550123" className="text-orange-600">(586) 555-0123</a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
