import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Check, 
  TrendingUp, 
  Search, 
  MapPin, 
  FileText, 
  Link as LinkIcon, 
  BarChart3,
  AlertTriangle,
  Star,
  Target,
  Zap,
  Shield
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

export function SEOPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-900/20 via-slate-950 to-slate-950" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0icmdiYSgyNTUsMTIwLDAsLjAzKSIvPjwvZz48L3N2Zz4=')] opacity-20" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6">
                Get Found. Get Customers. Grow Revenue.
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Dominate local search results and turn Google into your best lead source. Our proven SEO strategies get you to the top and keep you there.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
                  Get Free SEO Audit
                </Button>
                <Button size="lg" variant="outline" className="border-slate-700 text-white hover:bg-slate-800">
                  See Our Rankings
                </Button>
              </div>
              
              {/* Trust Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-slate-300">
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">Local SEO Experts</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">100% Transparent</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  <span className="text-sm">No Long Contracts</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <AlertTriangle className="w-16 h-16 text-orange-500 mx-auto mb-4" />
            <h2 className="text-white mb-4">Your Competitors Are Eating Your Lunch on Google</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              While you're waiting for the phone to ring, your competitors are showing up first on Google and stealing your customers.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">93%</div>
                <p className="text-slate-300">
                  of customers use Google to find local services
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">75%</div>
                <p className="text-slate-300">
                  never scroll past page 1 of search results
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 text-center">
                <div className="text-5xl text-orange-500 mb-2">5×</div>
                <p className="text-slate-300">
                  more leads from SEO than paid ads
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* What We Do */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">What We Do</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Comprehensive SEO services designed to get you found by customers who are ready to buy.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Google Business Profile</h3>
                <p className="text-slate-400 text-sm">
                  Optimize your GBP to dominate the local map pack. Show up when customers search "near me."
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Search className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Keyword Research</h3>
                <p className="text-slate-400 text-sm">
                  Find and target the exact phrases your customers are searching for. No wasted effort.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">On-Page Optimization</h3>
                <p className="text-slate-400 text-sm">
                  Optimize every page of your site to rank higher and convert better.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Content Creation</h3>
                <p className="text-slate-400 text-sm">
                  High-quality content that ranks well and establishes you as the local expert.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <LinkIcon className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Local Citations</h3>
                <p className="text-slate-400 text-sm">
                  Build your presence across directories and review sites to boost local rankings.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 h-full">
                <div className="bg-orange-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-white mb-2">Monthly Reporting</h3>
                <p className="text-slate-400 text-sm">
                  Clear, transparent reports showing your rankings, traffic, and leads. No fluff.
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Results/Case Studies */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Real Rankings. Real Results.</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              See how we've helped Michigan businesses dominate their local markets.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8">
                <div className="mb-6">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1599658880436-c61792e70672?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFya2V0aW5nJTIwYW5hbHl0aWNzfGVufDF8fHx8MTc2MTkzMjU0Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="SEO analytics"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                </div>
                <Badge className="bg-orange-500/10 text-orange-500 mb-3">HVAC Company</Badge>
                <h3 className="text-white mb-4">From Invisible to #1</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">5 → 23</div>
                    <div className="text-slate-400 text-sm">Page 1 Keywords</div>
                  </div>
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">8 → 47</div>
                    <div className="text-slate-400 text-sm">Monthly Leads</div>
                  </div>
                </div>
                <p className="text-slate-400 text-sm">
                  "We went from page 5 to consistently ranking #1-3 for our main services. Our phone rings constantly now." - Mike J.
                </p>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8">
                <div className="mb-6">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1591696205602-2f950c417cb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGdyb3d0aCUyMGNoYXJ0fGVufDF8fHx8MTc2MTg4NjAyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Growth chart"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                </div>
                <Badge className="bg-orange-500/10 text-orange-500 mb-3">Dental Practice</Badge>
                <h3 className="text-white mb-4">Doubled Patient Inquiries</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">3 → 18</div>
                    <div className="text-slate-400 text-sm">Top 3 Rankings</div>
                  </div>
                  <div>
                    <div className="text-orange-500 text-2xl mb-1">+215%</div>
                    <div className="text-slate-400 text-sm">Organic Traffic</div>
                  </div>
                </div>
                <p className="text-slate-400 text-sm">
                  "We now dominate the local search results. New patient calls have more than doubled in 6 months." - Dr. Sarah C.
                </p>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Packages/Pricing */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">SEO Packages</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Flexible packages designed for businesses at every stage. Month-to-month — no long-term lock-ins.
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-500 transition-colors">
                <h3 className="text-white mb-2">Starter</h3>
                <div className="text-3xl text-orange-500 mb-1">$1,500</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Google Business Profile Optimization</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Keyword Research & Strategy</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">On-Page SEO (5 pages)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Local Citations (10/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Monthly Reporting</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full border-slate-700 text-white hover:bg-slate-800">
                  Get Started
                </Button>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-orange-500 p-8 h-full relative overflow-hidden">
                <Badge className="absolute top-4 right-4 bg-orange-600 text-white">Most Popular</Badge>
                <h3 className="text-white mb-2">Growth</h3>
                <div className="text-3xl text-orange-500 mb-1">$2,500</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Everything in Starter</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">On-Page SEO (15 pages)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Content Creation (2 posts/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Local Citations (20/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Review Management</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Competitor Analysis</span>
                  </li>
                </ul>
                <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                  Get Started
                </Button>
              </Card>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-8 h-full hover:border-orange-500 transition-colors">
                <h3 className="text-white mb-2">Domination</h3>
                <div className="text-3xl text-orange-500 mb-1">$4,000</div>
                <div className="text-sm text-slate-500 mb-6">per month</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Everything in Growth</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Unlimited On-Page SEO</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Content Creation (4 posts/mo)</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Premium Link Building</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Multi-Location SEO</span>
                  </li>
                  <li className="flex items-start gap-2 text-slate-300">
                    <Check className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Dedicated Account Manager</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full border-slate-700 text-white hover:bg-slate-800">
                  Get Started
                </Button>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">The Process</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              A proven system that delivers results month after month.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex gap-6"
              >
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-orange-500/10 border-2 border-orange-500 flex items-center justify-center">
                    <Target className="w-8 h-8 text-orange-500" />
                  </div>
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-white mb-2">Month 1: Deep Audit & Foundation</h3>
                  <p className="text-slate-400">
                    Complete SEO audit, keyword research, competitor analysis, and GBP optimization. We identify quick wins and build your strategy.
                  </p>
                </div>
              </motion.div>

              <div className="ml-8 h-12 w-px bg-gradient-to-b from-orange-500 to-transparent" />

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="flex gap-6"
              >
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-orange-500/10 border-2 border-orange-500 flex items-center justify-center">
                    <Zap className="w-8 h-8 text-orange-500" />
                  </div>
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-white mb-2">Months 2-3: Optimize & Build</h3>
                  <p className="text-slate-400">
                    On-page optimization, content creation, citation building, and technical fixes. You'll start seeing ranking improvements.
                  </p>
                </div>
              </motion.div>

              <div className="ml-8 h-12 w-px bg-gradient-to-b from-orange-500 to-transparent" />

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="flex gap-6"
              >
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-orange-500/10 border-2 border-orange-500 flex items-center justify-center">
                    <Shield className="w-8 h-8 text-orange-500" />
                  </div>
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-white mb-2">Month 4+: Scale & Dominate</h3>
                  <p className="text-slate-400">
                    Continuous optimization, aggressive content strategy, and advanced link building. You'll dominate your local market.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4">Frequently Asked Questions</h2>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  How long does SEO take to show results?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  Most clients start seeing ranking improvements within 2-3 months, with significant results by month 6. SEO is a long-term strategy — but the results compound over time and continue improving.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Do you require long-term contracts?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  No. All our packages are month-to-month. We earn your business every month by delivering results. You're free to cancel anytime with 30 days notice.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  What if I'm already on page 1?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  We'll keep you there and expand to more keywords. Even if you're ranking well, there's always opportunity to capture more traffic and leads in adjacent areas.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  Do you guarantee #1 rankings?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  No one can guarantee #1 rankings (anyone who does is lying). What we guarantee is that we'll use proven strategies, work hard for you, and be 100% transparent about progress and results.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="bg-slate-900 border-slate-800 rounded-lg px-6">
                <AccordionTrigger className="text-white hover:text-orange-500">
                  What makes you different from other SEO agencies?
                </AccordionTrigger>
                <AccordionContent className="text-slate-400">
                  We specialize in Michigan service businesses. We're local, transparent, and focused on real results — not vanity metrics. Plus, we don't lock you into long-term contracts.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-900/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6">Ready To Own Page 1?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Get a free SEO audit and see exactly where you stand — and how we can get you to the top.
            </p>
            <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white">
              Get Free SEO Audit
            </Button>
            <p className="text-sm text-slate-500 mt-4">
              No cost. No obligation. Just honest insights into your SEO.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
