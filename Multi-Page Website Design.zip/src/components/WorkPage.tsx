import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ExternalLink, Code, Zap, TrendingUp } from 'lucide-react';

export function WorkPage() {
  const projects = [
    {
      name: 'Royaltronix',
      url: 'https://www.royaltronix.store',
      description: 'Premium e-commerce store for electronics and gadgets with seamless checkout experience',
      category: 'E-Commerce',
      tech: ['Shopify', 'Custom Design', 'Payment Integration'],
      results: ['+250% conversion rate', '4.8★ customer rating', '$125K+ monthly revenue']
    },
    {
      name: 'SwiftRooter',
      url: 'https://swiftrooter.framer.website/',
      description: 'Modern plumbing service website with instant booking and emergency call features',
      category: 'Service Business',
      tech: ['Framer', 'Booking System', 'Mobile-First'],
      results: ['+340% bookings', '24/7 online scheduling', '4X more leads']
    },
    {
      name: 'Viral Launch',
      url: 'https://viral-launch.netlify.app/',
      description: 'High-converting landing page for product launches with built-in analytics',
      category: 'Landing Page',
      tech: ['React', 'Performance Optimized', 'A/B Testing'],
      results: ['< 1s load time', '67% conversion rate', '10K+ signups']
    },
    {
      name: 'The Luxanta',
      url: 'https://theluxanta.com/',
      description: 'Luxury brand website showcasing premium products with elegant design',
      category: 'Luxury Brand',
      tech: ['WordPress', 'Custom Theme', 'SEO Optimized'],
      results: ['+180% organic traffic', 'Page 1 Google rankings', '5-star design award']
    }
  ];

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-slate-950 to-slate-950" />
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div {...fadeInUp}>
              <h1 className="text-white mb-6 text-5xl lg:text-6xl">
                Websites That Drive Real Results
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                We don't just build beautiful websites. We build lead-generating machines that help businesses grow. Here's proof.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto"
          >
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 text-center">
                <div className="text-5xl text-orange-600 mb-2">50+</div>
                <div className="text-slate-300">Websites Built</div>
              </Card>
            </motion.div>
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 text-center">
                <div className="text-5xl text-orange-600 mb-2">95%</div>
                <div className="text-slate-300">Client Satisfaction</div>
              </Card>
            </motion.div>
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 text-center">
                <div className="text-5xl text-orange-600 mb-2">3.5X</div>
                <div className="text-slate-300">Average ROI</div>
              </Card>
            </motion.div>
            <motion.div variants={fadeInUp}>
              <Card className="bg-slate-900 border-slate-800 p-6 text-center">
                <div className="text-5xl text-orange-600 mb-2">2 yrs</div>
                <div className="text-slate-300">In Business</div>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Portfolio */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">Featured Projects</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Every project is built with Framer, Figma, or WordPress — whatever works best for your needs
            </p>
          </motion.div>

          <motion.div
            variants={staggerChildren}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid lg:grid-cols-2 gap-8"
          >
            {projects.map((project, index) => (
              <motion.div key={project.name} variants={fadeInUp}>
                <Card className="bg-slate-900 border-slate-800 overflow-hidden h-full hover:border-orange-600 transition-all group">
                  {/* Project Preview */}
                  <div className="relative aspect-video bg-slate-800 overflow-hidden">
                    <iframe
                      src={project.url}
                      className="w-full h-full"
                      title={project.name}
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <a 
                        href={project.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg flex items-center gap-2"
                      >
                        <ExternalLink className="w-5 h-5" />
                        Visit Live Site
                      </a>
                    </div>
                  </div>

                  <div className="p-8">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-white text-2xl mb-2">{project.name}</h3>
                        <Badge className="bg-orange-600/20 text-orange-600">{project.category}</Badge>
                      </div>
                      <a 
                        href={project.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-orange-600 hover:text-orange-500 transition-colors"
                      >
                        <ExternalLink className="w-6 h-6" />
                      </a>
                    </div>

                    <p className="text-slate-400 mb-6">{project.description}</p>

                    <div className="mb-6">
                      <div className="text-slate-500 text-sm mb-2">Built With:</div>
                      <div className="flex flex-wrap gap-2">
                        {project.tech.map((tech) => (
                          <Badge key={tech} className="bg-slate-800 text-slate-300 border-slate-700">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-slate-500 text-sm mb-3">Results:</div>
                      <div className="grid grid-cols-3 gap-3">
                        {project.results.map((result) => (
                          <div key={result} className="bg-slate-800 rounded-lg p-3 text-center">
                            <div className="text-orange-600 text-sm">{result}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-white mb-4 text-4xl">How We Build Websites That Convert</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="bg-slate-900 border-slate-800 p-8 text-center">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Code className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">Design That Converts</h3>
              <p className="text-slate-400">
                We don't just make it pretty. Every element is designed to guide visitors toward taking action.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8 text-center">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">Lightning Fast Performance</h3>
              <p className="text-slate-400">
                Under 2 seconds load time. Mobile-optimized. Fast sites rank better and convert more.
              </p>
            </Card>

            <Card className="bg-slate-900 border-slate-800 p-8 text-center">
              <div className="bg-orange-600/10 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-white text-xl mb-3">Built To Rank</h3>
              <p className="text-slate-400">
                SEO-optimized from day one. Your website is built to show up when customers search.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Technologies */}
      <section className="py-20 bg-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-white mb-6 text-3xl">We Build With The Best Tools</h2>
            <p className="text-slate-300 mb-12">
              Framer, Figma, WordPress — we use whatever technology fits your needs best
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              {['Framer', 'Figma', 'WordPress', 'Shopify', 'React', 'Custom Code'].map((tech) => (
                <div key={tech} className="bg-slate-900 border-2 border-slate-800 rounded-xl px-8 py-4">
                  <span className="text-white text-lg">{tech}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-orange-600/20 via-slate-950 to-slate-950">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-white mb-6 text-4xl lg:text-5xl">Ready For A Website Like These?</h2>
            <p className="text-xl text-slate-300 mb-8">
              Let's build something that makes your competitors jealous and your phone ring
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/quote">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white text-xl px-10 py-8">
                  Get Free Quote
                </Button>
              </a>
              <a href="tel:5863658389">
                <Button size="lg" variant="outline" className="border-2 border-slate-700 text-white hover:bg-slate-800 text-xl px-10 py-8">
                  Call (586) 365-8389
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
