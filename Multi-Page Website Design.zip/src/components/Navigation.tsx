import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/button';
import { Menu, X, Phone, Anvil } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  return (
    <>
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-slate-950/98 backdrop-blur-md shadow-xl border-b border-orange-500/20' : 'bg-slate-950/80 backdrop-blur-sm'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <Anvil className="w-7 h-7 text-orange-600" />
              <div className="flex flex-col leading-none">
                <span className="text-white text-sm sm:text-base">Michigan Digital Foundry</span>
                <span className="text-orange-600 text-xs hidden sm:block">Warren, MI</span>
              </div>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center gap-6">
              <Link to="/services" className="text-slate-300 hover:text-orange-600 transition-colors">
                Services
              </Link>
              <Link to="/work" className="text-slate-300 hover:text-orange-600 transition-colors">
                Our Work
              </Link>
              <Link to="/about" className="text-slate-300 hover:text-orange-600 transition-colors">
                About
              </Link>
              <Link to="/contact" className="text-slate-300 hover:text-orange-600 transition-colors">
                Contact
              </Link>
            </div>

            {/* Phone & CTA */}
            <div className="hidden lg:flex items-center gap-4">
              <a href="tel:5863658389" className="flex items-center gap-2 text-orange-600 hover:text-orange-500 transition-colors">
                <Phone className="w-4 h-4" />
                <span className="font-semibold">(586) 365-8389</span>
              </a>
              <Link to="/quote">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white shadow-lg shadow-orange-600/20">
                  Get Free Quote
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-slate-950 lg:hidden pt-20"
          >
            <div className="container mx-auto px-4 py-8 flex flex-col gap-6">
              <Link to="/services" className="text-white text-xl hover:text-orange-600 transition-colors">
                Services
              </Link>
              <Link to="/work" className="text-white text-xl hover:text-orange-600 transition-colors">
                Our Work
              </Link>
              <Link to="/about" className="text-white text-xl hover:text-orange-600 transition-colors">
                About
              </Link>
              <Link to="/contact" className="text-white text-xl hover:text-orange-600 transition-colors">
                Contact
              </Link>
              <div className="border-t border-slate-800 pt-6 mt-4">
                <a href="tel:5863658389" className="flex items-center gap-2 text-orange-600 mb-4 text-xl">
                  <Phone className="w-5 h-5" />
                  <span className="font-semibold">(586) 365-8389</span>
                </a>
                <Link to="/quote">
                  <Button size="lg" className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                    Get Free Quote
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
