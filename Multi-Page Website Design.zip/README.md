
  # Multi-Page Website Design

  This is a code bundle for Multi-Page Website Design. The original project is available at https://www.figma.com/design/DAj1Uu0b03HCE53CGtZjOR/Multi-Page-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  